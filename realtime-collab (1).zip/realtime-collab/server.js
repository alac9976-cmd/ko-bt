# server.js
const express = require('express');
const http = require('http');
const path = require('path');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static(path.join(__dirname, 'public')));

// Serve index.html from public folder
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

let doc = ''; // keep latest document on server (simple approach)

io.on('connection', (socket) => {
  console.log('user connected', socket.id);
  // send current document to newly connected client
  socket.emit('init', { doc });

  socket.on('edit', (data) => {
    // data: {content, sender}
    doc = data.content; // update server copy
    // broadcast to everyone except sender
    socket.broadcast.emit('remoteEdit', { content: data.content, sender: data.sender });
  });

  socket.on('disconnect', () => {
    console.log('user disconnected', socket.id);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Server listening on http://localhost:${PORT}`));
